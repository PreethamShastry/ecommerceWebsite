import React from 'react'
import { NavLink } from 'react-router-dom'
import "../styles/Adminmenu.css"

const AdminMenu = () => {
  return (
    <>
    
        <div className=" text-center">
            <div className="list-group">
                <h1 className='adminpanel'>admin panel</h1>
                <div className='types'>
                <NavLink to="/dashboard/admin/create-category " className="list-group-item list-group-action"> create Category</NavLink>
                <NavLink to="/dashboard/admin/create-product " className="list-group-item list-group-action"> create product</NavLink>
                <NavLink to="/dashboard/admin/products " className="list-group-item list-group-action"> Products</NavLink>
                <NavLink to="/dashboard/admin/orders " className="list-group-item list-group-action"> Orders</NavLink>
                {/* <NavLink to="/dashboard/admin/users " className="list-group-item list-group-action">Users</NavLink> */}
                </div>
            </div>
        </div>
        

    
    
    
    </>
  )
}

export default AdminMenu