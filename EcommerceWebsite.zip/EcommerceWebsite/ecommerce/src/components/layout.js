import React from 'react'
// import Header from './header';
import Head from './Head';
import Footer from './footer';
import {Helmet} from "react-helmet";
// import { ToastContainer } from 'react-toastify';
import  { Toaster } from 'react-hot-toast';
// import 'react-toastify/dist/ReactToastify.css';
const layout = ({children, title, description,keywords,author}) => {
  return (
    <div>
        <Helmet>
                <meta charSet="utf-8" />
                     <div>
                    <meta name="description" content={description} />
                    <meta name="keywords" content={keywords} />
                    <meta name="author" content={author} />
                    </div>

                <title>{title}</title>
              
        </Helmet>
        <Head/>
        <main style={{minHeight:"80vh"}}> 
        <Toaster />
        {children} </main>
        <Footer/>
    </div>
  )
}

layout.defaultProps = {
  title : "ecommerce webssite",
  description : "shopping website",
  keywords :"mern",
  author : "preetham"
}

export default layout;