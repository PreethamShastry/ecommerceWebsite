import React from 'react'
import "../styles/Usermenu.css"

import { NavLink } from 'react-router-dom'
const UserMenu = () => {
  return (
    <>
            <div className="text-center">
            <div className="list-group">
                <h1 className='userpanel'>user panel</h1>
                <div className="userpanellist">
              
                <NavLink to="/dashboard/user/profile " className="list-group-item list-group-action"> profile</NavLink>
                <NavLink to="/dashboard/user/orders " className="list-group-item list-group-action"> orders</NavLink>
                </div>
                
            
            </div>
        </div>
    
    
    
    
    
    </>
  )
}

export default UserMenu
