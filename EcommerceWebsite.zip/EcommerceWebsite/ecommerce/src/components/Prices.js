export const Prices = [
    {
        _id: 0,
        name : "$0 to 19",
        array : [0, 19],
    },
    {
        _id: 1,
        name : "$20 to 39",
        array : [20, 39],
    },
    {
        _id: 2,
        name : "$40 to 59",
        array : [40, 59],
    },
    {
        _id: 3,
        name : "$60 to 79",
        array : [60, 79],
    },
    {
        _id: 4,
        name : "$80 to 99",
        array : [80, 99],
    },
    {
        _id: 5,
        name : "$100 to 129",
        array : [100, 129],
    },
    {
        _id: 6,
        name : "$130 to 159",
        array : [130, 159],
    },{
        _id: 7,
        name : "$160 or more",
        array : [160, 9999],
    }

]


export default Prices;