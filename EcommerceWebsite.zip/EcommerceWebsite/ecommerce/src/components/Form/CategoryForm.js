import React from 'react'
import "../../styles/Categoryform.css"

const CategoryForm = ( { handleSubmit, value, setValue } ) => {
  return (
    <>
                <form onSubmit={ handleSubmit }>
                <div className="mb-3">
                    <input type="text" className="form-control"  placeholder='enter new category' value={value} onChange={ (e)=>setValue(e.target.value) }  />

                </div>
                    
               
                
                <button type="submit" className="btnsubmit btn-primary">Submit</button>
                </form>

    
    
    </>
  )
}

export default CategoryForm
