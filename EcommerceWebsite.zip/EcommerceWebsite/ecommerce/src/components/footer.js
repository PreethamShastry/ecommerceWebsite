import React from 'react'
import { Link } from 'react-router-dom'
import "../styles/Footer.css"
const footer = () => {
  return (
    // change it to footer
    <div className='footerbg text-light p-3'> 
        <h1 className='footertxt text-center '>All Rights reserved &copy; kakunje software</h1>
        {/* <p className="text-center mt-3" >
            <Link to='/about'>about</Link>

            <Link to='/contact'>contact</Link>

            <Link to='/policy'>policy</Link>
        </p> */}
    </div>
  )
}

export default footer