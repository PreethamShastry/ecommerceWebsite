import { useState, useContext, createContext } from "react";


const SearchContext = createContext()



const SearchProvider = ({children}) =>{
    const [auth, setAuth] = useState({

        keyword : "",
        results : [],
    
    })

    // // deafult axios
    // axios.defaults.headers.common['Authorization'] = auth?.token





    // to save data in local storage so that it wont clear during refresh
   /* useEffect( () =>{
        const data = localStorage.getItem('auth')
        if(data){
            const parseData = JSON.parse(data)
            setAuth({
                ...auth,
                user : parseData.user,
                token : parseData.token
            })
        }
         // eslint-disable-next-line
    }, []) */
    return(
        <SearchContext.Provider value={[auth, setAuth]}>
            {children}
        </SearchContext.Provider>
    )
}

// customm hook
const useSearch = () => useContext(SearchContext)

export { useSearch, SearchProvider}