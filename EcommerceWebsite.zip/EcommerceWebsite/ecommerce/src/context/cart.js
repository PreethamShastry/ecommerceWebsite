import { useState, useContext, createContext, useEffect } from "react";


const CartContext = createContext()



const CartProvider = ({children}) =>{
    const [cart, setCart] = useState([])

    useEffect(() => {
        let existingCartItem = localStorage.getItem("cart");
        if (existingCartItem) setCart(JSON.parse(existingCartItem));
      }, []);

    // // deafult axios
    // axios.defaults.headers.common['Authorization'] = auth?.token
  
    // //to increment and decrement
    // const setDecrease = (id) =>{
    //     dispatchEvent({ type: 'SET_DECREMENT', payload: id})
    // }

    // const setIncrement = (id) =>{
    //     dispatchEvent({ type: 'SET_INCREMENT', payload: id})
    // }

    return(
        <CartContext.Provider value={[cart, setCart]}>
            {children}
        </CartContext.Provider>
    )
}

// customm hook
const useCart = () => useContext(CartContext)

export { useCart, CartProvider}