import React from 'react';
// import './App.css';
// import Layout from './components/layout';
import { Routes, Route} from 'react-router-dom'
// import Homepage from './pages/homepage';
import Home from './pages/Home';
import About from './pages/about';
import Contact from './pages/contact';
import Policy from './pages/policy';
import Notfound from './pages/notfound';
import Registration from './pages/auth/Registration'
import Loggin from './pages/auth/Loggin';
import 'react-toastify/dist/ReactToastify.css';
import Dashboard from './pages/user/Dashboard';
import PrivateRoute from './components/Routes/Private';
import Forgotpassword from './pages/auth/Forgotpassword';
import AdminRoute from './components/Routes/AdminRoute';
import AdminDboard from './pages/Admin/AdminDboard';
import CreateCategory from './pages/Admin/CreateCategory';
import CreateProduct from './pages/Admin/CreateProduct';
import Users from './pages/Admin/Users';
import Userpage from './pages/user/Userpage';
import Order from './pages/user/Order';
import Products from './pages/Admin/Products';
// import UpdateProduct from './pages/Admin/UpdateProduct';
import UpdateProduct from './pages/Admin/UpdateProduct';
import SearchPage from './pages/SearchPage';
import ProductDetails from './pages/ProductDetails';
import Categories from './pages/Categories';
import CategoryProduct from './pages/CategoryProduct';
import CartPage from './pages/CartPage';
import AdminOrders from './pages/Admin/AdminOrders';


function App() {
  return (
   <>
      {/* <Layout>
        <h1>hello</h1>
      </Layout> */}
      <Routes>
        <Route path='/' element = {<Home />} />
        <Route path='/product/:slug' element = {<ProductDetails />} />
        <Route path='/categories' element = {<Categories />} />
        <Route path='/cart' element = {<CartPage />} />
        <Route path='/category/:slug' element = {<CategoryProduct />} />
        <Route path='/search' element = {<SearchPage />} />
        <Route path='/dashboard' element={<PrivateRoute/>}>
             <Route path='user' element = {<Dashboard />} />
             <Route path='user/profile' element = {<Userpage />} />
             <Route path='user/orders' element = {<Order />} />
        </Route>
        <Route path= '/dashboard' element={<AdminRoute/>}>
            <Route path='admin' element = {<AdminDboard />} />
            <Route path='admin/create-category' element = {<CreateCategory />} />
            <Route path='admin/create-product' element = {<CreateProduct />} />
            {/* <Route path='admin/update-product/:slug' element = {<UpdateProduct />} /> */}
            <Route path='admin/product/:slug' element = {<UpdateProduct />} />
            <Route path='admin/products' element = {<Products />} />
            <Route path = 'admin/users' element = {<Users/>} />
            <Route path = 'admin/orders' element = {<AdminOrders/>} />
            
        </Route>
        <Route path='/forgot-password' element = {<Forgotpassword />} />
        <Route path='/register' element = {<Registration />} />
        <Route path='/login' element = {<Loggin />} />
        <Route path='/about' element = {<About />} />
        <Route path='/contact' element = {<Contact/>} />
        <Route path='/policy' element = {<Policy />} />
        <Route path='*' element = {<Notfound />} />
      </Routes>
   </>
  );
}

export default App;
