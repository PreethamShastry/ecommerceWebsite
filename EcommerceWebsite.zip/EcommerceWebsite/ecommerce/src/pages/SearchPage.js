import React from 'react'
import Layout from '../components/layout'
import { useSearch } from '../context/Search'



const SearchPage = () => {
    const [ values, setValues] = useSearch()

  return (
    <Layout title='search results'>
        <div className="container">
            <div className="text-center">
                <h1>SEARCH RESLUT</h1>
                <h6>{ values?.results.length < 1? 'no product found' : `product found ${values?.results.length }` }</h6>
                <div className="d-flex flex-wrap mt-5">
              
              {values?.results.map((p) =>(         
                            <div className="card m-3" style={{width: '18rem'}} >
                                <img src={`/api/v1/product/product-photo/${p._id}`} className="card-img-top " alt={p.name} />
                                <div className="card-body">
                                    <h5 className="card-title">{p.name}</h5>
                                    <p className="card-text">{p.description.substring(0,30)}</p>
                                    <p className="cardprice card-text">${p.price}</p>
                                    <button  class="btnmore btn-primary ms-2">more details</button>
                                    <button  class="btnadd btn-secondary ms-2">add to cart</button>
                                </div>
                            </div>
                       
                         

                    ))}
            </div>
            </div>
        </div>

    </Layout>
  )
}

export default SearchPage