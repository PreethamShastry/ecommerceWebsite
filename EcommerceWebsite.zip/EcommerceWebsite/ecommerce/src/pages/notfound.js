import React from 'react'
import Layout from '../components/layout'
const notfound = () => {
  return (
    <Layout>
        <div className="pnf text-center">
          <h1>404</h1>
          <p>Oops!Page not found</p>

        </div>
    </Layout>
  );
}

export default notfound