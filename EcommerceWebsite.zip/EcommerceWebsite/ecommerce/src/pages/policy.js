import React from 'react'
import Layout from '../components/layout'
const policy = () => {
  return (
   <Layout>
        <h1>this is policy</h1>
   </Layout>
  );
}

export default policy
