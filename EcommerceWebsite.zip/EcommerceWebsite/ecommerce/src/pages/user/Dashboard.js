import React from 'react'
import Layout from '../../components/layout'
import UserMenu from '../../components/UserMenu'
import { useAuth } from '../../context/auth'
import "../../styles/Dashboarduser.css"
import whatsapplogo from "../../img/whatsapp.jpeg"

const Dashboard = () => {
  const [auth] = useAuth()
  return (
    <Layout title={'dashboard'}>
          <div className="container-fluid m-3 p-3">
        <div className="row">
            <div className="col-md-3">
                <UserMenu />
            </div>
            <div className="col-md-9">
              <div className="carduser w-75 p-3"></div>
               <h4 className='userdcard'>UserName: {auth?.user?.name}</h4>
               <h4 className='userdcard'>UserEmail: {auth?.user?.email}</h4>
               <h4 className='userdcard'>UserAddress: {auth?.user?.address}</h4>
            </div>
            
        </div>
        </div>
        <div className='fixed-bottom right-100 p-3' style={ {zIndex: "6", left: "initial"}}>
          <a href="https://wa.me/918892882988?text=Hello ?" target='_blank'>
            <img src={whatsapplogo} width="60" alt='aaa'/>
          </a>
        </div>
    </Layout>
  )
}

export default Dashboard