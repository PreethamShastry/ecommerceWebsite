import React from 'react'
import Layout from '../../components/layout'
import UserMenu from '../../components/UserMenu'
import { useAuth } from '../../context/auth'
import "../../styles/Dashboarduser.css"

const Dashboard = () => {
  const [auth] = useAuth()
  return (
    <Layout title={'dashboard'}>
          <div className="container-fluid m-3 p-3">
        <div className="row">
            <div className="col-md-3">
                <UserMenu />
            </div>
            <div className="col-md-9">
              <div className="carduser w-75 p-3"></div>
               <h4 className='userdcard'>UserName: {auth?.user?.name}</h4>
               <h4 className='userdcard'>UserEmail: {auth?.user?.email}</h4>
               <h4 className='userdcard'>UserAddress: {auth?.user?.address}</h4>
            </div>
            
        </div>
        </div>
    </Layout>
  )
}

export default Dashboard