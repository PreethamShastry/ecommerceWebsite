import React,{useState, useEffect} from 'react'
import Layout from '../components/layout'
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import axios from 'axios';
import { Checkbox, Radio } from 'antd';
import  Prices  from '../components/Prices';
import { useCart } from '../context/cart';
import "../styles/Homepage.css";
import whatsapplogo from "../img/whatsapp.jpeg"

const Home = () => {

    // context api
    

    const[products, setProducts] = useState([])
    const[categories, setCategories] = useState([])
    const [ cart, setCart] = useCart()
    const[checked, setChecked] = useState([])
    const[radio, setRadio] = useState([])
    const[total, setTotal] = useState(0)
    const[page, setPage] = useState(1)
    const[loading, setLoading] = useState(false)
    const navigate = useNavigate()

  




    // get all category
    const getAllCategory = async (req,res) =>{
      try {
        const { data } = await axios.get('/api/v1/category/get-category')
        if(data?.success){
          setCategories(data?.category)
        }
        
      } catch (error) {
        console.log(error)
        
        
      }
    }
    useEffect( () =>{
        getAllCategory()
        getTotal()
    },[])




    //get all products
    const getAllProducts = async () =>{
      try {
        setLoading(true)
        const {data} = await axios.get(`/api/v1/product/product-list/${page}`)
        setLoading(false)
        setProducts(data.products)
        
      } catch (error) {
        setLoading(false)
        console.log(error)
        toast.error("something went wrong in home/get all products")
        
      }
    }
    useEffect( () =>{
        getAllProducts()
    }, [])

     //total count
     const getTotal = async () =>{
      try {
        const { data } = await axios.get('/api/v1/product/product-count')
        setTotal(data?.total)
      } catch (error) {
        console.log(error)
        
      }
    }

    useEffect( () =>{
      if(page === 1 ) return
      loadMore()
    },[page])
    //load more function
    const loadMore = async () =>{
      try {
          setLoading(true)
          const {data} = await axios.get(`/api/v1/product/product-list/${page}`)
          setLoading(false)
          setProducts([...products, ...data?.products])
      } catch (error) {
        console.log(error)
        setLoading(false)
        
      }
    }




      //filter by category
  const handleFilter = (value,id) => {
    let all = [...checked]
    if(value){
      all.push(id)
    }else{
      all = all.filter(c => c!== id)
    }
    setChecked(all)
  } 
  useEffect( () =>{
    if(!checked.length || !radio.length) getAllProducts()
    
  }, [checked.length, radio.length]) 




 


  // get filtered product
  const filterProduct = async() => {
    try {
        const {data} = await axios.post('/api/v1/product/product-filters',{checked,radio})
        setProducts(data?.products)
    } catch (error) {
      console.log(error)
      
    }
  }
  useEffect( () =>{
    if(checked.length || radio.length) filterProduct()
    
  }, [checked, radio]) 







  return (
    <Layout title={'home'}>


    {/* image silders */}
          <div id="carouselExampleSlidesOnly" className="carousel slide" data-bs-ride="carousel">
                <div className="carousel-inner">
                  <div className="slider carousel-item active">
                    <img src="https://static.rapidonline.com/img/raspberrypi/new/banners/raspberry-pi-4-new-banner.jpg" className="d-block w-100" alt="..." />
                  </div>
                  {/* <div className="carousel-item">
                    <img src="https://www.okdo.com/wp-content/uploads/2021/07/arduino-banner-1200x350-1.jpg?fit=1300%2C400" className="d-block w-100" alt="..." />
                  </div>
                  <div className="carousel-item">
                    <img src="https://www.okdo.com/wp-content/uploads/2021/07/arduino-banner-1200x350-1.jpg?fit=1300%2C400" className="d-block w-100" alt="..." />
                  </div> */}
                </div>
              </div>


        <div className="body row mt-3">
          <div className="col-md-3">
            <div className='categorybord'>
            <h3 className='text-center'>FILTER BY CATEGORY</h3>
            <div className="category d-flex flex-column">
            {categories?.map((c) => (
              <Checkbox className='catcheck' key={c._id} onChange={ (e) => handleFilter(e.target.checked, c._id) }>
                {c.name}
              </Checkbox>
            ))}
            </div>
            </div>
            {/* price filter */}
            <div className='pricebrod'>
            <h3 className='text-center '>FILTER BY PRICE</h3>
            <div className="price  d-flex flex-column ">
                <Radio.Group className='priceradio' onChange={ e =>setRadio(e.target.value) }>
                  {Prices?.map( (p) =>(
                    <div key={p.id}>
                    <Radio value={p.array}>{p.name}</Radio>
                    </div>
                  ))}
                </Radio.Group>
            </div>
            </div>

            <div className="d-flex flex-column">
                <button className='btn01  m-auto' onClick={ () => window.location.reload()}> RESET  FILTERS </button>
            </div>
            
          </div>
          <div className="productbrod col-md-9">
            {/* {JSON.stringify(radio,null,4)} */}
            <h1 className='h1home'>FEATURED PRODUCTS</h1>
            <div className="allprod d-flex flex-wrap">
              
              {products?.map((p) =>(         
                            <div className="card m-4" style={{width: '18rem'}} >
                                <img src={`/api/v1/product/product-photo/${p._id}`} className="card-img-top " alt={p.name} />
                                <div className="card-body">
                                    <h5 className="card-title">{p.name}</h5>
                                    <p className="card-text">{p.description.substring(0,30)}</p>
                                    <p className="cardprice card-text">${p.price}</p>
                                    <button  class="btnmore btn-primary ms-2" 
                                    onClick={ () => navigate(`/product/${p.slug}`) }
                                    >MORE DETAILS </button>
                                    <button  class="btnadd btn-secondary ms-2"
                                     onClick={ () =>{ 
                                      setCart([...cart,p])
                                      localStorage.setItem('cart', JSON.stringify([...cart, p]))
                                      toast.success('item added to cart succesfully')
                                      } }>ADD TO CART</button>
                                </div>
                            </div>
                       
                         

                    ))}
            </div>
            <div className='m-2 p-3'>
              { products && products.length < total && (
                <button className="btn btn-warning" 
                onClick={ (e) =>{
                  e.preventDefault()
                  setPage( page + 1)
                }}>
                  { loading ? "loading..." : "load-more" }
                </button>
              ) }
              
            </div>
          </div>
        </div>
        <div className='fixed-bottom right-100 p-3' style={ {zIndex: "6", left: "initial"}}>
          <a href="https://wa.me/918892882988?text=Hello ?" target='_blank'>
            <img src={whatsapplogo} width="60" alt='aaa'/>
          </a>
        </div>
    </Layout>
  )
}

export default Home
