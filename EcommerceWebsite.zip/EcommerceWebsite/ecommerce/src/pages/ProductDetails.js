import React, { useState, useEffect } from 'react'
import Layout from '../components/layout'
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { useNavigate  } from 'react-router-dom';
import "../styles/Productdetails.css"

const ProductDetails = () => {
    const navigate = useNavigate()
    const params = useParams()
    const [product, setProduct] = useState({})
    const [relatedProducts, setRelatedProducts] = useState([]);



    //inital product details
  useEffect(() => {
    if (params?.slug) getProduct();
  }, [params?.slug]);

  //getProduct
  const getProduct = async () => {
    try {
      const { data } = await axios.get(
        `/api/v1/product/get-product/${params.slug}`
      );
      setProduct(data?.product);
       getSimilarProduct(data?.product._id, data?.product.category._id);
    } catch (error) {
      console.log(error);
    }
  };

  //get similar product
  const getSimilarProduct = async (pid, cid) => {
    try {
      const { data } = await axios.get(
        `/api/v1/product/related-product/${pid}/${cid}`
      );
      setRelatedProducts(data?.products);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Layout>
        
        {/* {JSON.stringify(product, null, 4)} */}
        <div className=" row container mt-3">
            <div className="col-md-6">
            <img src={`/api/v1/product/product-photo/${product._id}`} className="card-img-top " alt={product.name} height="200" width={'75px'} />
            </div>
            <div className="col-md-6">
                <h3 className='text-center'>details</h3>
                <h4> NAME: {product.name}</h4>
                <p> DESCRIPTION: {product.description}</p>
                < p> CATEGORY : {product?.category?.name}</p> 
                <h4 className='cardprice'> PRICE:${product.price}</h4>
                <button  class="btnadd  btn-secondary ms-2">add to cart</button>
            </div>
        </div>
        <hr />
        <div className="row container">
            <h5>similar products</h5>
            { relatedProducts.length < 1 && ( <p className='text-center'> no similar product found  </p>)}
            <div className="d-flex flex-wrap">
              
              {relatedProducts?.map((p) =>(         
                            <div className="card m-3" style={{width: '18rem'}} >
                                <img src={`/api/v1/product/product-photo/${p._id}`} className="card-img-top " alt={p.name} />
                                <div className="card-body">
                                    <h5 className="card-title">{p.name}</h5>
                                    <p className="card-text">{p.description.substring(0,30)}</p>
                                    <p className="cardprice card-text"> $ {p.price}</p>
                                    
                                    <button  class="btnadd btn-secondary ms-2">ADD TO CART</button>
                                </div>
                            </div>
                       
                         

                    ))}
            </div>
        </div>
    </Layout>
  )
}

export default ProductDetails