import React, {useState,useEffect} from 'react'
import { Link } from 'react-router-dom'
import Layout from '../components/layout'
import useCategory from '../hooks/useCategory'
import whatsapplogo from "../img/whatsapp.jpeg"

const Categories = () => {

    const categories = useCategory()

  return (
    <Layout title={'all categories'}>
            <div className="container">
                <div className="row">
                    {categories?.map( (c) => (
                    <div className="col-md-6 mt-5 md-3 gx-5 gy-5 " key = {c._id}>
                        
                            {/* <img src="https://tse2.mm.bing.net/th?id=OIP.Z7JiQaFe5xBABL7QsL8kSAHaE8&pid=Api&P=0&h=180" alt="" />  check  in home for photo*/}
                            
                            <Link to={ `/category/${ c.slug }` } className='btn btn-primary'>{c.name}</Link>
                        
                    </div>
                    ))}
                    </div>
            </div>
            <div className='fixed-bottom right-100 p-3' style={ {zIndex: "6", left: "initial"}}>
          <a href="https://wa.me/918892882988?text=Hello ?" target='_blank'>
            <img src={whatsapplogo} width="60" alt='aaa'/>
          </a>
        </div>
    </Layout>
  )
}

export default Categories