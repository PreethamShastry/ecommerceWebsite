import React from 'react'
import Layout from './../../components/layout.js';
import AdminMenu from '../../components/AdminMenu.js';
import { useAuth } from '../../context/auth.js';
import "../../styles/Admindash.css"

const AdminDboard = () => {
  const [auth] = useAuth()
  return (
    <Layout title={'admin'}>
            <div className="container-fluid m-3 p-3">
              <div className="row">
                <div className="col-md-3">
                  <AdminMenu/>
                </div>
                <div className="admincard col-md-9">
                  <div className="cardadmin w-75 p-2">
                    <h4> ADMIN NAME:{auth?.user?.name}</h4>
                    <h4> ADMIN EMAIL:{auth?.user?.email}</h4>
                    <h4> ADMIN CONTACT:{auth?.user?.phone}</h4>
                  </div>
                </div>
              </div>

            </div>
    </Layout>
  )
}

export default AdminDboard
