import React, { useState, useEffect } from 'react'
import Layout from '../components/layout'
import {  useCart } from '../context/cart'
import { useAuth } from '../context/auth'
import { useNavigate } from 'react-router-dom'
import DropIn from "braintree-web-drop-in-react";
import axios from 'axios'
import toast from 'react-hot-toast'
import { AiFillWarning } from "react-icons/ai";
import whatsapplogo from "../img/whatsapp.jpeg"

const CartPage = () => {
    const navigate = useNavigate()
    const[auth, setAuth] = useAuth()
    const[cart, setCart] = useCart() 
    const [instance, setInstance] = useState("");
    const [loading, setLoading] = useState(false);
    const [clientToken, setClientToken] = useState()
    const [amount, setAmount] = useState(1)
    
    
    

      //total price
  const totalPrice = () => {
    try {
      let total = 0;
      cart?.map((item) => {
        total = (total + JSON.parse(item.price))*amount;
      });
      return total.toLocaleString("en-US", {
        style: "currency",
        currency: "USD",
      });
    } catch (error) {
      console.log(error);
    }
  };

    //delete item from cart
    const removeCartItem = (pid) =>{
        try {
            let myCart = [...cart]
            let index = myCart.findIndex( item => item._id === pid)
            myCart.splice(index,1)
            setCart(myCart)
            localStorage.setItem('cart', JSON.stringify(myCart))
            
        } catch (error) {
            console.log(error)
            
        }
    }

     //get payment gateway token
  const getToken = async () => {
    try {
      const { data } = await axios.get("/api/v1/product/braintree/token");
      setClientToken(data?.clientToken);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getToken();
  }, [auth?.token]);

  //handle payments
  const handlePayment = async () => {
    try {
      setLoading(true);
      const { nonce } = await instance.requestPaymentMethod();
      const { data } = await axios.post("/api/v1/product/braintree/payment", {
        nonce,
        cart,
      });
      setLoading(false);
      localStorage.removeItem("cart");
      setCart([]);
      navigate("/dashboard/user/orders");
      toast.success("Payment Completed Successfully ");
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  // // increase and decresese quantity
  const setDecrease = (pid) =>{
    // cart?.map( (p) =>{
    //   if(_pid === _pid){
    //     amount  > 1 ? setAmount(amount-1) : setAmount(1)
    //   }
    // })
    try {
      let myCart = [...cart]
      let index = myCart.findIndex( item => item._id === pid)
      amount  > 1 ? setAmount(amount-1) : setAmount(1)
      
    } catch (error) {
      console.log(error)
    }
    

  }

  const setIncrement = (pid) =>{
    // cart?.map((p) => {
    //   if(_pid == _pid){
    //   amount < JSON.parse(p.quantity) ? setAmount(amount+1) : setAmount(p.quantity)
    //   }
    // });
    try {
      let myCart = [...cart]
      let index = myCart.findIndex( item => item._id === pid)
      cart?.map ((p)=>{
        amount < (p.quantity) ? setAmount(amount+1) : setAmount(p.quantity)
      })
    } catch (error) {
      console.log(error)
      
    }
    
  }


  return (
    <Layout>
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <h1 className="text-center bg-light p-3 mb-1">
                        {`Hello ${auth?.token && auth?.user?.name}`}
                    </h1>
                    <h4 className='text-center'>
                            {cart?.length
                        ? `You Have ${cart.length} items in your cart ${
                            auth?.token ? "" : "please login to checkout !"
                            }`
                        : " Your Cart Is Empty"}
                    </h4>
                </div>
                
            </div>
            <div className="row">
                <div className="col-md-6">
                {
                    cart?.map( (p) => (
                        <div className="row mb-4 p-3 card flex-row">
                            <div className="col-md-4 ">
                            <img src={`/api/v1/product/product-photo/${p._id}`} className="card-img-top  " width="100px" height={'100px'} alt={p.name} />
                            </div>
                            <div className="col-md-7">
                               <p>{p.name}</p>
                               <p>{p.description.substring(0,30)}</p>
                               <p>price :${p.price}</p>
                               {/* <p>qunatity: {p.quantity}</p> */}
                               <div className="input-group">
                                <button type="button" className='input-group-text' onClick={ () => setDecrease(p._id)}>-</button>
                                <div className="form-control text-center" >Qty = {amount}</div>
                                <button type="button" className='input-group-text' onClick={ () => setIncrement(p._id)}>+</button>
                               </div>
                               <button className="btn btn-danger" 
                                onClick={ () => removeCartItem(p._id)}
                               >Remove</button>
                            </div>
                        </div>
                    ))
                }
                </div>
                <div className="col-md-3 text-center">
                  <h4> ORDER SUMMARY</h4>
                  <p>total | checkout  | payment</p>
                  <hr />
                  <h3 >total: { totalPrice() }</h3>
                  {auth?.user?.address ? (
                <>
                  <div className="mb-3">
                    <h4>Current Address</h4>
                    <h5>{auth?.user?.address}</h5>
                    <button
                      className="btnsubmit btn-outline-warning"
                      onClick={() => navigate("/dashboard/user/profile")}
                    >
                      Update Address
                    </button>
                  </div>
                </>
              ) : (
                <div className="mb-3">
                  {auth?.token ? (
                    <button
                      className="btn btn-outline-warning"
                      onClick={() => navigate("/dashboard/user/profile")}
                    >
                      Update Address
                    </button>
                  ) : (
                    <button
                      className="btn-outline-warning"
                      onClick={() =>
                        navigate("/login", {
                          state: "/cart",
                        })
                      }
                    >
                      Please Login to checkout
                    </button>
                  )}
                </div>
              )}
              <div className="mt-2">
                {!clientToken || !auth?.token || !cart?.length ? (
                  ""
                ) : (
                  <>
                    <DropIn
                      options={{
                        authorization: clientToken,
                        paypal: {
                          flow: "vault",
                        },
                      }}
                      onInstance={(instance) => setInstance(instance)}
                    />

                    <button
                      className="btn btn-primary"
                      onClick={handlePayment}
                      disabled={loading || !instance || !auth?.user?.address}
                    >
                      {loading ? "Processing ...." : "Make Payment"}
                    </button>
                  </>
                )}
              </div>
                </div>
            </div>
        </div>
        <div className='fixed-bottom right-100 p-3' style={ {zIndex: "6", left: "initial"}}>
          <a href="https://wa.me/918892882988?text=Hello ?" target='_blank'>
            <img src={whatsapplogo} width="60" alt='aaa'/>
          </a>
        </div>
    </Layout>
  )
}

export default CartPage