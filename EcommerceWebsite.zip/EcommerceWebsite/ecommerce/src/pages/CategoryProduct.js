import React, {useState, useEffect} from 'react'
import Layout from '../components/layout'
import axios from 'axios'
import { useParams,useNavigate } from 'react-router-dom'
import "../styles/Categoryproduct.css"


const CategoryProduct = () => {

    const params = useParams()
    const navigate = useNavigate()
    const [products, setProducts] = useState([])
    const [category, setCategory] = useState([])

    const getProductsByCat = async () => {
        try {
            const { data } = await axios.get(`/api/v1/product/product-category/${params.slug}`)
            setProducts(data?.products)
            setCategory(data?.category)
            
        } catch (error) {
            console.log(error)
            
        }
    }
    useEffect( () =>{
       if(params?.slug) getProductsByCat()
    }, [params?.slug])
  return (
    <Layout>
        <div className="conatiner mt-3">
            <h1 className="productsFound text-center">{products?.length} PRODUCTS FOUND</h1>
            <h1 className="categotytype text-center">CATEGORY:{category?.name}</h1>
            <div className="row">
            <div className="d-flex flex-wrap">
              
              {products?.map((p) =>(         
                            <div className="card m-3" style={{width: '18rem'}} >
                                <img src={`/api/v1/product/product-photo/${p._id}`} className="card-img-top " alt={p.name} />
                                <div className="card-body">
                                    <h5 className="card-title">{p.name}</h5>
                                    <p className="card-text">{p.description.substring(0,30)}</p>
                                    <p className="cardprice card-text"> $ {p.price}</p>
                                    <button  class="btnmore btn-primary ms-2" 
                                    onClick={ () => navigate(`/product/${p.slug}`) }
                                    >more details</button>
                                    <button  class="btnadd btn-secondary ms-2">add to cart</button>
                                </div>
                            </div>
                       
                         

                    ))}
            </div>
            </div>
        </div>
    </Layout>
  )
}

export default CategoryProduct