import React,{useState} from 'react'
import Layout from '../../components/layout'
import axios from 'axios';
// import { toast } from 'react-toastify';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import "../../styles/Register.css"

const Registration = () => {
    const [name,setName] = useState("");
    const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");
    const [phone,setPhone] = useState("");
    const [address,setAddress] = useState("");
    const [answer,setAnswer] = useState("");
    const navigate = useNavigate();

    // prevents from refreshing the page
    const handleSubmit = async (e) =>{
            e.preventDefault()
            try {
                    const res = await axios.post('/api/v1/auth/register',
                    {name, email, password, phone, address, answer});
                    if(res && res.data.success){
                        toast.success(res.data.message)
                        navigate('/login')
                    }
                    else{
                        toast.error(res.data.message)
                    }
                
            } catch (error) {
                console.log(error)
                toast.error("something went wrong")
            }
    }
  return (
    <Layout title={'register'}>
    <div className="register">
        <div className='loginformreg'>
        <h1>REGISTRATION</h1>
            <form onSubmit={handleSubmit}>
            <div className="mb-2">
                <label htmlFor="exampleInputName" className="form-label">Name</label>
                <input type="text" value={name} 
                onChange={(e) => setName(e.target.value) } 
                className="form-control" id="exampleInputName" 
                required />
                
            </div>
            <div className="mb-2">
            <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
            <input type="email" value={email} 
            onChange={(e) => setEmail(e.target.value) } 
            className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" 
            required/>
            </div>

            <div className="mb-2">
                <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                <input type="password" value={password}
                onChange={(e) => setPassword(e.target.value) } 
                 className="form-control" id="exampleInputPassword1"
                 required />
            </div>
            <div className="mb-2">
                <label htmlFor="exampleInputPhone" className="form-label">phone</label>
                <input type="text" value={phone} 
                onChange={(e) => setPhone(e.target.value) } 
                className="form-control" id="exampleInputPhone"
                required  />
                
            </div>
            <div className="mb-2">
                <label htmlFor="exampleInputAddress" className="form-label">Address</label>
                <input type="text" value={address} 
                onChange={(e) => setAddress(e.target.value) } 
                 className="form-control" id="exampleInputAddress" 
                 required />
                
            </div>
            <div className="mb-3">
                <label htmlFor="exampleInputAnswer" className="form-label">answer</label>
                <input type="text" value={answer} 
                onChange={(e) => setAnswer(e.target.value) } 
                className="form-control" id="exampleInputAnswer"
                required  />
                
            </div>
            
            <button type="submit" className="btnlogpageinreg btn-primary">Submit</button>
            </form>

            
             
            </div>
    </div>
</Layout>
  )
}

export default Registration