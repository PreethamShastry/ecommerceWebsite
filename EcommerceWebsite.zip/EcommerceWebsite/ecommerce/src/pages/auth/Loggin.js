import React,{useState} from 'react'
import Layout from '../../components/layout'
import axios from 'axios';
// import { toast } from 'react-toastify';
import toast from 'react-hot-toast';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/auth';
import "../../styles/Login.css"

const Loggin = () => {
    // const [name,setName] = useState("");
    const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");
    const [auth, setAuth] = useAuth()
    // const [phone,setPhone] = useState("");
    // const [address,setAddress] = useState("");
    const navigate = useNavigate();
    const location = useLocation();

     // prevents from refreshing the page
     const handleSubmit = async (e) =>{
        e.preventDefault()
        try {
                const res = await axios.post('/api/v1/auth/login',
                { email, password});
                if(res.data.success){
                    toast.success(res.data.message)
                    // context api
                    setAuth({
                        ...auth,
                        user : res.data.user,
                        token : res.data.token,
                    })
                    localStorage.setItem('auth',JSON.stringify(res.data))
                    navigate( location.state || '/')
                }
                else{
                    toast.error(res.data.message)
                }
            
        } catch (error) {
            console.log(error)
            toast.error("something went wrong")
        }
}

  return (
    <Layout title={'log in'}>
        
        <div className="register">
            
         <div className='loginform'>
        <h1 className='loginoflogin'>LOG IN</h1>
            <form onSubmit={handleSubmit}>
            {/* <div className="mb-3">
                <label htmlFor="exampleInputName" className="form-label">Name</label>
                <input type="text" value={name} 
                onChange={(e) => setName(e.target.value) } 
                className="form-control" id="exampleInputName" 
                required />
                
            </div> */}
            <div className="mb-3">
            <label htmlFor="exampleInputEmail1" className="form-label" >Enter your Email address</label>
            <input type="email" value={email} 
            onChange={(e) => setEmail(e.target.value) } 
            className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" 
            required/>
            </div>

            <div className="mb-3">
                <label htmlFor="exampleInputPassword1" className="form-label">Enter your Password</label>
                <input type="password" value={password}
                onChange={(e) => setPassword(e.target.value) } 
                 className="form-control" id="exampleInputPassword1"
                 required />
            </div>
            {/* <div className="mb-3">
                <label htmlFor="exampleInputPhone" className="form-label">phone</label>
                <input type="text" value={phone} 
                onChange={(e) => setPhone(e.target.value) } 
                className="form-control" id="exampleInputPhone"
                required  />
                
            </div>
            <div className="mb-3">
                <label htmlFor="exampleInputAddress" className="form-label">Address</label>
                <input type="text" value={address} 
                onChange={(e) => setAddress(e.target.value) } 
                 className="form-control" id="exampleInputAddress" 
                 required />
                
            </div> */}
            
             <button type="submit" className="btnlogpagein btn-primary mt-3">LOG IN</button>
             
                <div className='divforlogin'>
                <button type="submit" className="btnforgot btn-primary" onClick={() =>{navigate('/forgot-password')}}>forgot-password</button>
                </div>
            
           
            
            </form>
            </div>    

    </div>
    </Layout>
  )
}

export default Loggin
