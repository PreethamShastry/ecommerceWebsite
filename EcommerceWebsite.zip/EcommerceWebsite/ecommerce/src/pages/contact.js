import React from 'react'
import Layout from '../components/layout'
const contact = () => {
  return (
    <Layout title={'contact us'}>
        <h1>this is coontact</h1>
    </Layout>
  );
}

export default contact
