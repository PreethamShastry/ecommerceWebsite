import React from 'react'
import Layout from '../components/layout'
const about = () => {
  return (
    <Layout title={'about us'}>
        <h1>this about page</h1>
    </Layout>
  );
}

export default about